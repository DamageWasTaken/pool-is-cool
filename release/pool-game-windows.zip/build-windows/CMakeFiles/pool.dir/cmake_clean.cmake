file(REMOVE_RECURSE
  "CMakeFiles/pool.dir/src/area.cpp.o"
  "CMakeFiles/pool.dir/src/area.cpp.o.d"
  "CMakeFiles/pool.dir/src/ball.cpp.o"
  "CMakeFiles/pool.dir/src/ball.cpp.o.d"
  "CMakeFiles/pool.dir/src/button.cpp.o"
  "CMakeFiles/pool.dir/src/button.cpp.o.d"
  "CMakeFiles/pool.dir/src/font.cpp.o"
  "CMakeFiles/pool.dir/src/font.cpp.o.d"
  "CMakeFiles/pool.dir/src/main.cpp.o"
  "CMakeFiles/pool.dir/src/main.cpp.o.d"
  "CMakeFiles/pool.dir/src/math.cpp.o"
  "CMakeFiles/pool.dir/src/math.cpp.o.d"
  "CMakeFiles/pool.dir/src/physics.cpp.o"
  "CMakeFiles/pool.dir/src/physics.cpp.o.d"
  "CMakeFiles/pool.dir/src/renderwindow.cpp.o"
  "CMakeFiles/pool.dir/src/renderwindow.cpp.o.d"
  "CMakeFiles/pool.dir/src/texturemanager.cpp.o"
  "CMakeFiles/pool.dir/src/texturemanager.cpp.o.d"
  "pool"
  "pool.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/pool.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
