
# Consider dependencies only in project.
set(CMAKE_DEPENDS_IN_PROJECT_ONLY OFF)

# The set of languages for which implicit dependencies are needed:
set(CMAKE_DEPENDS_LANGUAGES
  )

# The set of dependency files which are needed:
set(CMAKE_DEPENDS_DEPENDENCY_FILES
  "/home/lucas/Documents/Development/Pool/src/area.cpp" "CMakeFiles/pool.dir/src/area.cpp.o" "gcc" "CMakeFiles/pool.dir/src/area.cpp.o.d"
  "/home/lucas/Documents/Development/Pool/src/ball.cpp" "CMakeFiles/pool.dir/src/ball.cpp.o" "gcc" "CMakeFiles/pool.dir/src/ball.cpp.o.d"
  "/home/lucas/Documents/Development/Pool/src/button.cpp" "CMakeFiles/pool.dir/src/button.cpp.o" "gcc" "CMakeFiles/pool.dir/src/button.cpp.o.d"
  "/home/lucas/Documents/Development/Pool/src/font.cpp" "CMakeFiles/pool.dir/src/font.cpp.o" "gcc" "CMakeFiles/pool.dir/src/font.cpp.o.d"
  "/home/lucas/Documents/Development/Pool/src/main.cpp" "CMakeFiles/pool.dir/src/main.cpp.o" "gcc" "CMakeFiles/pool.dir/src/main.cpp.o.d"
  "/home/lucas/Documents/Development/Pool/src/math.cpp" "CMakeFiles/pool.dir/src/math.cpp.o" "gcc" "CMakeFiles/pool.dir/src/math.cpp.o.d"
  "/home/lucas/Documents/Development/Pool/src/physics.cpp" "CMakeFiles/pool.dir/src/physics.cpp.o" "gcc" "CMakeFiles/pool.dir/src/physics.cpp.o.d"
  "/home/lucas/Documents/Development/Pool/src/renderwindow.cpp" "CMakeFiles/pool.dir/src/renderwindow.cpp.o" "gcc" "CMakeFiles/pool.dir/src/renderwindow.cpp.o.d"
  "/home/lucas/Documents/Development/Pool/src/texturemanager.cpp" "CMakeFiles/pool.dir/src/texturemanager.cpp.o" "gcc" "CMakeFiles/pool.dir/src/texturemanager.cpp.o.d"
  )

# Targets to which this target links which contain Fortran sources.
set(CMAKE_Fortran_TARGET_LINKED_INFO_FILES
  )

# Targets to which this target links which contain Fortran sources.
set(CMAKE_Fortran_TARGET_FORWARD_LINKED_INFO_FILES
  )

# Fortran module output directory.
set(CMAKE_Fortran_TARGET_MODULE_DIR "")
